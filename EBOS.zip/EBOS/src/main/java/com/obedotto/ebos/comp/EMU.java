/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.obedotto.ebos.comp;
import com.obedotto.ebos.comp.mem.Memory;
import com.obedotto.ebos.comp.cpu.CPU;

/**
 *
 * @author ottoo
 */
public class EMU {
    
    private final Memory mem;
    private final CPU cpu;
    
    public EMU(){
        this.mem = new Memory();
        this.cpu = new CPU();
    }
    
}
